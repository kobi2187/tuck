#!/bin/bash
# usage: q.sh dir [flags] ; prints compact per-backend result. stdout merged+stderr
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
d=$1; shift
cd $d
chk=$(/home/user/tuck/tuck ch t.tuck 2>&1 | grep -v "^SIZE\|TK-CX\|^OK" | head -5)
[ -n "$chk" ] && echo "CHECK: $chk"
one() {
  b=$1; shift
  mkdir -p b_$b; cp t.tuck b_$b/t.tuck; cd b_$b
  case $b in nim) f=""; BIN=./t;; odin) f="--odin"; BIN=./t_odin;; d) f="--dlang"; BIN=./t_d;; esac
  rm -f $BIN
  /home/user/tuck/tuck b t.tuck $f "$@" > build.log 2>&1 || { echo "BUILD FAIL: $(grep -i 'error' build.log | head -3)" > out.txt; return; }
  timeout 10 $BIN > o.out 2> o.err; ec=$?
  { echo "exit=$ec"; cat o.out | head -${LINES_MAX:-60}; [ -s o.err ] && echo "STDERR: $(head -3 o.err)"; } > out.txt
}
for b in nim odin d; do one $b "$@" & done; wait
for b in nim odin d; do echo "--- $b"; cat b_$b/out.txt; done
