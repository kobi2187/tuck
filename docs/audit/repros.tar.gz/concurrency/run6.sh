#!/bin/bash
# usage: run6.sh dir file.tuck [extra flags]
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
d=$(realpath -m $1); f=$(realpath $2); shift 2
mkdir -p $d
for be in nim odin dlang; do
 for mode in stackless stackful; do
  o=$d/$be-$mode; mkdir -p $o
  flag=""; [ $be = odin ] && flag=--odin; [ $be = dlang ] && flag=--dlang
  cp $f $o/p.tuck
  out=$(cd $o && timeout 120 /home/user/tuck/tuck b p.tuck $flag --concurrency:$mode -o:$o "$@" 2>&1)
  rc=$?
  bin=p
  [ $be = odin ] && bin=p_odin; [ $be = dlang ] && bin=p_d
  [ -x "$o/p" ] && bin=p
  if [ $rc -ne 0 ]; then echo "[$be/$mode] BUILD FAIL: $(echo "$out" | head -5)"; continue; fi
  res=$(cd $o && timeout 20 ./$bin 2>&1); ec=$?
  echo "[$be/$mode] exit=$ec out=$(echo "$res" | tr '\n' '|' | cut -c1-300)"
 done
done
