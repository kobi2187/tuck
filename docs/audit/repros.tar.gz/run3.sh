#!/bin/bash
# usage: run3.sh dir  (dir/a.tuck)
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
d=$1; shift
cd $d
for b in nim odin d; do
  mkdir -p $d/_$b; cp $d/*.tuck $d/_$b/
  cd $d/_$b
  case $b in nim) fl="";; odin) fl="--odin";; d) fl="--dlang";; esac
  /home/user/tuck/tuck b a.tuck $fl "$@" > build.log 2>&1 || { echo "[$b] BUILD FAIL"; head -5 build.log; continue; }
  echo "[$b]"; bin=./a; [ -x ./a_odin ] && bin=./a_odin; [ -x ./a_d ] && bin=./a_d; timeout 20 $bin > out.txt 2> err.txt; echo "exit=$?"; head -c 600 out.txt; head -c 800 err.txt
done
