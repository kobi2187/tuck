#!/bin/bash
# usage: run3.sh dir main.tuck   (copies all *.tuck in dir to dir/{nim,odin,d})
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
T=/home/user/tuck/tuck; R="--root:/home/user/tuck"
cd "$1"; f="$2"; b="${f%.tuck}"
$T ch $f $R || { echo "CHECK FAIL"; exit 1; }
for be in nim odin d; do
  mkdir -p $be; cp *.tuck $be/
  case $be in nim) fl="";; odin) fl="--odin";; d) fl="--dlang";; esac
  ( cd $be; $T b $f $fl $R > build.log 2>&1 || { echo "[$be] BUILD FAIL"; tail -4 build.log; exit 0; }
    case $be in nim) x=./$b;; odin) x=./${b}_odin;; d) x=./${b}_d;; esac
    timeout 10 $x > out.txt 2>&1; echo "[$be] rc=$? out=$(head -c 300 out.txt | tr '\n' '|')" )
done
