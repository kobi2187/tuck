#!/bin/bash
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
d=$(readlink -f $1)
for b in nim odin d; do
  mkdir -p $d/$b; cp $d/*.tuck $d/$b/
  cd $d/$b
  case $b in nim) fl=""; bin=main;; odin) fl="--odin"; bin=main_odin;; d) fl="--dlang"; bin=main_d;; esac
  echo "== $b"; /home/user/tuck/tuck b main.tuck $fl 2>&1 | grep -iv "^SIZE\|TK-CX\|^wrote\|^built\|^OK\|^$\|TK-EF02" | head -8
  [ -x ./$bin ] && { timeout 10 ./$bin; echo "exit=$?"; }
  cd ../..
done
