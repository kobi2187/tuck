#!/bin/bash
# usage: run.sh dir  (dir contains main.tuck)
export PATH=/root/toolchains/nim/bin:/root/toolchains/odin:/root/toolchains/ldc2/bin:/root/toolchains/dmd2/linux/bin64:$PATH
d=$1
cd $d
echo "== check"; /home/user/tuck/tuck ch main.tuck 2>&1 | head -${2:-15}
